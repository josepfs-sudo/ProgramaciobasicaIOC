/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da2_m03b2_eac6_solucio;

import java.io.*;


public class GestorFitxers {
    
    static final String USER_DIR = "user.dir";
    public String carpetaDadesOriginal = "";
    
    
    /**
     * Canvia la carpeta en la que es troba apuntant l'aplicació.
     * @param carpeta nom de la nova carpeta on ubicar-se
     * @return 
     */
    public boolean canviarCarpetaTreball(String carpeta){
        File fCarp = new File(carpeta);
        if ( fCarp.exists() ){
            System.setProperty(USER_DIR, carpeta);
        }else{
            return false;
        }
        return true;
    }
    
   
    /**
     * Retorna la carpeta on es troba ubicada l'aplicació
     * @return 
     */
    public String obtenirCarpetaTreball(){
        return System.getProperty("user.dir");
    }
    
    /**
     * Fa un recorregut per tots els fitxers de la carpeta on es troba
     * ubicada l'aplicació i mostra el nom i la mida dels fitxers que 
     * tenen l'extensió indicada com a paràmetre
     * @param extensio que han de tenir els fitxers que es mostraran
     */
    public void mostrarFitxersSegonsExtensio(String extensio){
        String carpetaTreball = System.getProperty("user.dir");
        File fCarpeta = new File(carpetaTreball);
        File[] fitxers = fCarpeta.listFiles();
        System.out.println("-------------------------------");
        System.out.println(String.format("%-20s %10s", "NOM FITXER", "BYTES"));
        System.out.println("-------------------------------");
        for (File f : fitxers){
            if ( f.getName().endsWith(extensio) ){
                System.out.println(String.format("%-20s %10d", f.getName(), f.length()));
            }
        }
        System.out.println("-------------------------------");
    }
    
}

