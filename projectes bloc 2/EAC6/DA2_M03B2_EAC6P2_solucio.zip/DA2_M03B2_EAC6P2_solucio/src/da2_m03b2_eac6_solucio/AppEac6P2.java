/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da2_m03b2_eac6_solucio;

import java.util.*;

public class AppEac6P2 {
    
    /**
     * Variables globals corresponents als missatges que es mostren per pantalla
     */
    static final String MISSATGE_TRII_OPCIO = "Triï una opció";
    static final String MISSATGE_ERROR_OPCIO = "Opció incorrecta. Torni-ho a intentar";
    static final String MISSATGE_ERROR = "Error";
    static final String MISSATGE_COMIAT = "Què passis un bon dia!";
    static final String MISSATGE_CARPETA_DADES = "Carpeta on guardar les dades [Prem . per usar la carpeta de l'aplicacio]?";
    static final String MISSATGE_DEMANAR_CARPETA = "Quina és la nova carpeta de treball?";
    static final String MISSATGE_DEMANAR_EXTENSIO = "Introdueixi extensió fitxer: ";
    static final String MISSATGE_CANVI_OK = "Carpeta canviada correctament";
    static final String MISSATGE_CANVI_KO = "Error en canvi carpeta de treball";
    static final String MISSATGE_DEMANA_EXTENSIO = "Introdueix la nova extenió de treball";
    static final String MISSATGE_CARPETA_TREBALL = "La carpeta de treball és: ";
    static final String MISSATGE_EXTENSIO_TREBALL = "L'extensió de treball és: ";
    static final String MISSATGE_DADES_GRAVADES_OK = "Dades gravades correctament";
    static final String MISSATGE_DADES_GRAVADES_KO = "Dades gravades incorrectament";
    static final String MISSATGE_POSICIO = "Introdueix posició a partir de la qual mostrar dades (0 és la posició inicial): ";
    static final String EXTENSIO_PER_DEFECTE = "xml";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AppEac6P2 prg = new AppEac6P2();
        prg.inici();
    }
    
    void inici(){
        int opcio;
        GestorFitxers gestor = new GestorFitxers();
        String[] menu = {
            "MENÚ",
            "1. Canviar carpeta de treball",
            "2. Mostrar carpeta de treball",
            "3. Canviar extensió de treball",
            "4. Mostrar extensió de treball",
            "5. Mostrar fitxers de treball", 
            "6. Tractament dades", 
            "0. Sortir" 
        };
        
        
        String extensioTreball = EXTENSIO_PER_DEFECTE;
        String carpeta;
        gestor.carpetaDades = gestor.obtenirCarpetaTreball();

        do{
            InterficieUsuari.mostrarMenu(menu);
            opcio = Utils.demanarEnter(MISSATGE_TRII_OPCIO, MISSATGE_ERROR_OPCIO);
            
            switch(opcio){
                case 1:
                    carpeta = Utils.demanarString(MISSATGE_DEMANAR_CARPETA, 
                            MISSATGE_ERROR);
                    if ( gestor.canviarCarpetaTreball(carpeta) ){
                        InterficieUsuari.mostrarMissatge(MISSATGE_CANVI_OK);
                    }else{
                        InterficieUsuari.mostrarMissatge(MISSATGE_CANVI_KO);
                    }
                    break;
                case 2:
                    carpeta = gestor.obtenirCarpetaTreball();
                    InterficieUsuari.mostrarMissatge(MISSATGE_CARPETA_TREBALL + carpeta);
                    break;
                case 3:
                    extensioTreball = Utils.demanarString(MISSATGE_DEMANA_EXTENSIO, 
                            MISSATGE_ERROR);
                    break;
                case 4:
                    InterficieUsuari.mostrarMissatge(MISSATGE_EXTENSIO_TREBALL + extensioTreball);
                    break;
                case 5:
                    gestor.mostrarFitxersSegonsExtensio(extensioTreball);
                    break;
                case 6:
                    tractarSubMenu(gestor, extensioTreball);
                    break;
                case 0:
                    InterficieUsuari.mostrarMissatge(MISSATGE_COMIAT);
                    break;
                default:
                    InterficieUsuari.mostrarMissatge(MISSATGE_ERROR_OPCIO);
            }            
        }while ( opcio != 0 );
    }
    
    
    void tractarSubMenu(GestorFitxers gestor, String extensioTreball){
        String[] subMenu = {
            "SUBMENÚ",
            "1. Recollir dades",
            "2. Mostrar dades gravades",
            "3. Tornar al menú principal"
        };    
        int subOpcio = -1;
        
        do{
            InterficieUsuari.mostrarMenu(subMenu);
            subOpcio = Utils.demanarEnter(MISSATGE_TRII_OPCIO, MISSATGE_ERROR_OPCIO);
    
            switch (subOpcio){
                case 1:
                    String[][] arrayFitxers = gestor.obtenirFitxersSegonsExtensio(extensioTreball);
                    if ( gestor.gravarDades(arrayFitxers) )
                        InterficieUsuari.mostrarMissatge(MISSATGE_DADES_GRAVADES_OK);
                    else
                        InterficieUsuari.mostrarMissatge(MISSATGE_DADES_GRAVADES_KO);
                    break;
                case 2:
                    int posicio = Utils.demanarEnter(MISSATGE_POSICIO, MISSATGE_ERROR);
                    gestor.mostrarDadesGravades(posicio);
                    break;
                case 3:
                    break;
                default:
                    InterficieUsuari.mostrarMissatge(MISSATGE_ERROR_OPCIO);
            }
        }while (subOpcio != 3);
    }
    
}
