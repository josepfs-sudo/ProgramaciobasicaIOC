/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da2_m03b2_eac6_solucio;

import java.io.*;


public class GestorFitxers {
    static final String NOM_FITXER_BINARI = "dump.bin";
    static final String NOM_FITXER_LOG = "dump.log";
    static final String USER_DIR = "user.dir";
    static final int MIDA_NOM_FITXER = 20;
    static final int MIDA_TAMANY_FITXER = 1;
    static final int MIDA_REG = MIDA_NOM_FITXER * Character.SIZE / 8 +
            MIDA_TAMANY_FITXER * Long.SIZE / 8;
    
    public String carpetaDades = "";
    
    /**
     * Canvia la carpeta en la que es troba apuntant l'aplicació.
     * @param carpeta nom de la nova carpeta on ubicar-se
     * @return 
     */
    public boolean canviarCarpetaTreball(String carpeta){
        
        File fCarp = new File(carpeta);
        if ( fCarp.exists() ){
            System.setProperty(USER_DIR, carpeta);
        }else{
            return false;
        }
        return true;
    }
    
    /**
     * Retorna la carpeta on es troba ubicada l'aplicació
     * @return 
     */
    public String obtenirCarpetaTreball(){
        return System.getProperty(USER_DIR);
    }
    
    /**
     * Fa un recorregut per tots els fitxers de la carpeta on es troba
     * ubicada l'aplicació i mostra el nom i la mida dels fitxers que 
     * tenen l'extensió indicada com a paràmetre
     * @param extensio que han de tenir els fitxers que es mostraran
     */
    public void mostrarFitxersSegonsExtensio(String extensio){
        String carpetaTreball = System.getProperty(USER_DIR);
        File fCarpeta = new File(carpetaTreball);
        File[] fitxers = fCarpeta.listFiles();
        System.out.println("-------------------------------");
        System.out.println(String.format("%-20s %10s", "NOM FITXER", "BYTES"));
        System.out.println("-------------------------------");
        for (File f : fitxers){
            if ( f.getName().endsWith(extensio) ){
                System.out.println(String.format("%-20s %10d", f.getName(), f.length()));
            }
        }
        System.out.println("-------------------------------");
    }
    
    /**
     * A partir del paràmetre extensió genera un array de dues dimensions
     * on cada fila és la dupla fitxer i mida que ocupa en bytes d'aquella
     * carpeta
     * @param extensio que han de tenir els fitxers que s'informaran
     * @return array de dues dimensions amb la informació indicada
     */
    public String[][] obtenirFitxersSegonsExtensio(String extensio){
        String carpetaTreball = System.getProperty(USER_DIR);
        File fCarpeta = new File(carpetaTreball);
        File[] fitxers = fCarpeta.listFiles();
        
        int indexArray = 0;
        for (File f : fitxers){
            if ( f.getName().endsWith(extensio) ){
                indexArray++;
            }
        }
        
        String[][] arrayFitxers = new String[indexArray][2];
        indexArray = 0;
        for (File f : fitxers){
            if ( f.getName().endsWith(extensio) ){
                arrayFitxers[indexArray][0] = f.getName();
                arrayFitxers[indexArray][1] = Long.toString(f.length());
                indexArray++;
            }
        }
        return arrayFitxers;
    }
    
    /**
     * A partir de l'array informat com a paràmetre grava als fitxers
     * dump.bin i dump.log de la carpeta de dades de l'aplicació, 
     * les dades indicades en l'arrayFitxers
     * @param arrayFitxers array bidimensional d'String amb les dades a guardar
     * @return indica si l'operació s'ha realitzat correctament.
     */
    public boolean gravarDades(String[][] arrayFitxers){
        String carpetaActual = System.getProperty(USER_DIR);
        RandomAccessFile raf;
        PrintStream psLog;
        boolean gravatOk = true;
        
        try{
            System.setProperty(USER_DIR, carpetaDades);
            raf = new RandomAccessFile(new File(NOM_FITXER_BINARI), "rw");
            raf.seek(raf.length());
            psLog = new PrintStream(new File(NOM_FITXER_LOG));
            
            for ( int i = 0; i < arrayFitxers.length; i++ ){
                raf.writeChars(tractarCadena(arrayFitxers[i][0]));
                raf.writeLong(Long.parseLong(arrayFitxers[i][1]));
                psLog.println(String.format("%-20s %10s", arrayFitxers[i][0], 
                        arrayFitxers[i][1]));
            }
            
            raf.close();
            psLog.close();
            
        }catch(IOException ex){
            System.out.println("Error al gravar les dades: " + ex.getMessage());
            gravatOk = false;
        }
        
        System.setProperty(USER_DIR, carpetaActual);
        return gravatOk;
    }
    
    /** 
     * Agafa la cadena passada com a paràmetre i s'assegura que té 20 bytes 
     * omoplint amb espais en blanc si fa falta o retallan en cas que s'excedeixi
     * @param cadena String amb la cadena a tractar
     * @return cadena tractada
     */
    public String tractarCadena(String cadena){
        if (cadena.length() < 20 ){
            for ( int i = cadena.length(); i < MIDA_NOM_FITXER; i++ ){
                cadena += " ";
            }
        }else{
            cadena = cadena.substring(0, 20);
        }
        return cadena;  
    }
    
    /**
     * Accedeix a la carpeta de dades de l'aplicació i mostra el contingut
     * del fitxer binari dump.bin a partir de la posició informaada com a 
     * paràmetre i fins al final de la mateixa.
     * @param posicio valor a partir del qual mosrar.
     */
    public void mostrarDadesGravades(int posicio){
        String carpetaActual = System.getProperty(USER_DIR);
        RandomAccessFile raf;
        
        try{
            System.setProperty(USER_DIR, carpetaDades);
            raf = new RandomAccessFile(new File(NOM_FITXER_BINARI), "r");
            long numRegistres = raf.length() / MIDA_REG;
            
            if ( posicio > numRegistres ){
                System.out.println("Posició massa alta. Número de registres màxim: " + numRegistres);                
            }else{
                raf.seek(MIDA_REG * posicio);
                System.out.println("-------------------------------");
                System.out.println(String.format("%-20s %10s", "NOM FITXER", "BYTES"));
                System.out.println("-------------------------------");
                do{
                    String nom = llegirString(raf, MIDA_NOM_FITXER);
                    long mida = raf.readLong();
                    System.out.println(String.format("%-20s %10d", nom, mida));
                }while (raf.getFilePointer() < raf.length());
                System.out.println("-------------------------------");
            }
            raf.close();

        }catch(IOException ex){
            System.out.println("Error al mostrar les dades: " + ex.getMessage());
        }
        
        System.setProperty(USER_DIR, carpetaActual);
    }

    /**
     * A partir d'un fitxer binari indicat i posicionat el seu apuntador
     * llegeix la quantitat de caràcters indicats i ho retorna en forma 
     * de variable String
     * @param raf fitxer binari a llegir
     * @param mida quantitat de caràcters que es llegiran
     * @return String amb el valor dels caràcters llegits
     * @throws IOException 
     */
    String llegirString(RandomAccessFile raf, int mida) throws IOException{
        String retorn = "";
        for ( int i = 0; i < mida; i++ ){
            retorn += raf.readChar();
        }
        return retorn;
    }
}

