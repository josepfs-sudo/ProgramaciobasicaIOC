public class GestioProduccio {
	static final double relQuiLitres=0.7; //Relació entre quilograms i litres
	static final double capacitatApolla=0.75; 

    /*Mètode que calcular els litres màximes que es poden produir
      a partir dels % d'un producte i les quantitats acumulades al magatzem */
    public static int  calculaLitres(int [] aCup, int [] mQuant) {
        double minDiv=0;
        double div;
        double quilosAcum=0;
        for (int i=0; i<aCup.length;i++) { 
            if (aCup[i]>0){
                div=(double) mQuant[i]/aCup[i];
                if (div<minDiv || minDiv==0) {
                        minDiv=div;
                }
            }
        }			
        for (int j=0; j<aCup.length;j++) {
                quilosAcum=quilosAcum+aCup[j]*minDiv;
        }

        return (int) Math.round(quilosAcum*relQuiLitres);	 
    }
	
	/*Mètode que ens retornarà els quilograms necessaris per elaborar els litres
	 i % rebuts. */
    public static int[] calculaQuilogramsLitres(int litres, int []aCup ) {
        int [] mRes={0,0,0,0,0};
        int quilos=(int) Math.round(litres*(1/relQuiLitres));
            for (int i=1;i<aCup.length;i++) {
                    mRes[i]=(int) Math.round(quilos*(aCup[i])/100);
            }		
        return mRes;
    }
	
    public static void mostraProduccio(String[] aProducte, int[] aProduccio) {
        for (int j=0;j<aProducte.length;j++) {
            System.out.println("Del producte "+ aProducte[j] + " tenim " + aProduccio[j] + " ampolles.");
        }
    }
    
	
    public static int posicioProducte(String prod, String aProd[]) {
        boolean trobat=false;
    	int pos=-1;
    	for (int i=0;!trobat && i<aProd.length;i++){
            if (aProd[i].equals(prod)){
                trobat= true;
                pos =i;
            }
    	}
    	return pos;
    }
	
    public static  int  calculaAmpolles(String producte,String aProd[], int [][] mCup,  int [] mQuant) {
        int posProd=posicioProducte(producte,aProd);
        int litres=0;
        if (posProd>-1) {
                litres = calculaLitres(mCup[posProd],mQuant);
        }
        return (int) Math.round(litres/capacitatApolla);
    }
	
    public static int[] calculaQuilogramsAmpolles(int ampolles,String producte, String [] aProd, int [][] mCup ){
        int posProd=posicioProducte(producte,aProd);
        int[] resQuilAmp={0,0,0,0,0};
        if (posProd>-1) {
                resQuilAmp = calculaQuilogramsLitres((int) Math.round(ampolles*capacitatApolla),mCup[posProd]);
        }
        return resQuilAmp;

    }
}