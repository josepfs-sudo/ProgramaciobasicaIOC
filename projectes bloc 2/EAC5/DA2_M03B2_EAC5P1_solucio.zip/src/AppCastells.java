/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author josep
 */
public class AppCastells {
//dades de prova
    String [] aProducte= {"Cava Castells","Blanc Castells","Negre Castells"};
    int [][] mCupatge={{0,0,30,50,20},{0,0,100,0,0},{60,40,0,0,0}};
    int [] aProduccio={0,0,0};
    static final int maxMagatzem=25000;
    String mVarietat[] = {"Ull de llebre","Garnatxa","Xarel·lo","Macabeu","Parellada"};
    int mQuantitat[]={987,8376,6352,3254,4562};
    int quantitatTotalRaim = 0;
    
    public static void main(String[] args) {
        AppCastells prg = new AppCastells();
        prg.inici();
    }

    private void inici(){
        int opcio;
        
        do {
            System.out.println();
            System.out.println();
            System.out.println("Opcions Producció Castells");
            System.out.println("0. Sortir");
            System.out.println("1. Prova Calcular Ampolles necessàries");
            System.out.println("2. Prova Calcular Quilograms segons ampolles");
            System.out.println("3. Prova Calcular Quilograms segons ampolles");
            opcio=UtilsES.demanarEnter("Selecciona una opció",  "Aquest menú només accepta valors numèrics");
            switch( opcio){
                case 1: provaCalculAmpolles(); break;
                case 2: provaCalculQuilograms(); break;
                case 3: provaMostraProduccio(); break;
            }  
        }while (opcio!=0);
    }
    
    private void provaCalculAmpolles() {
        System.out.println("Cava Castells:" 
           + GestioProduccio.calculaAmpolles("Cava Castells",aProducte, mCupatge, mQuantitat));
        System.out.println("Blanc Castells:" 
           + GestioProduccio.calculaAmpolles("Blanc Castells",aProducte, mCupatge,  mQuantitat));
        System.out.println("Negre Castells:" 
           + GestioProduccio.calculaAmpolles("Negre Castells", aProducte, mCupatge,  mQuantitat));
        
    }

    private void provaCalculQuilograms() {
           int i;
           int [] mQuilProd; 
           mQuilProd = GestioProduccio.calculaQuilogramsAmpolles(10653,"Cava Castells", 
                                                                        aProducte,mCupatge);
           System.out.println("Per obtenir 10653 ampolles de Cava Castells calen:");
           for (i=0;i<mQuilProd.length;i++) {
                   System.out.println("Varietat: " + mVarietat[i] + " quilograms:" + mQuilProd[i]);
           }
           System.out.println("Per obtenir 10653 ampolles de Blanc Castells calen:");
           mQuilProd = GestioProduccio.calculaQuilogramsAmpolles(12332,"Blanc Castells",
                                                                         aProducte,mCupatge);
           for (i=0;i<mQuilProd.length;i++) {
                   System.out.println("Varietat: " + mVarietat[i] + " quilograms:" + mQuilProd[i]);
           }
           System.out.println("Per obtenir 10653 ampolles de Negre Castells calen:");
           mQuilProd = GestioProduccio.calculaQuilogramsAmpolles(11635,"Negre Castells",
                                                                          aProducte,mCupatge);
           for (i=0;i<mQuilProd.length;i++) {
                   System.out.println("Varietat: " + mVarietat[i] + " quilograms:" + mQuilProd[i]);
           }
    }

   public void provaMostraProduccio(){
        String [] aProducte= {"Cava Castells","Blanc Castells","Negre Castells"};
        int [] aProduccio={3429, 1230, 2189};
        System.out.println("La producció és la següent:");
        GestioProduccio.mostraProduccio(aProducte, aProduccio);
    }   
}
