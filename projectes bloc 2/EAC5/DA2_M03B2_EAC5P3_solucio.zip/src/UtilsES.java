import java.util.Scanner;
public class UtilsES {

	public static String demanarString(String missatge, String missatgeError) {
            Scanner scanner = new Scanner(System.in);
            String ret;
            boolean correcte=false;
            do{
                System.out.print(missatge);
                ret=scanner.nextLine();
                correcte = !ret.isEmpty();
                if(!correcte){
                    System.out.println();
                    System.out.println(missatgeError);
                }
            }while(!correcte);
            return ret;
        }
	
	public static int demanarEnter(String missatge, String missatgeError) {
            Scanner scanner = new Scanner(System.in);
            int ret;
            boolean correcte=false;
            do{
                System.out.print(missatge);
                correcte=scanner.hasNextInt();
                if(!correcte){
                    scanner.next();
                    System.out.println();
                    System.out.println(missatgeError);
                }
            }while(!correcte);
            ret = scanner.nextInt();  
            scanner.nextLine();
            return ret;
	}
        
    public static void mostrarTitol(String titol){
        System.out.println("*************************************************************");
        System.out.print("     ");
        System.out.println(titol);
        System.out.println("*************************************************************");
        System.out.println();
        System.out.println();
    }
    
    public static void mostrarResultat(String missatge){
        System.out.println();
        System.out.println(missatge);
        System.out.println("--------------------------------------------------------------");
        System.out.println();
        System.out.println();
    }

    public static void mostrarAlesta(String missatge){
        System.out.println("======= ALERTA ===============================================");
        System.out.println(missatge);
        System.out.println("--------------------------------------------------------------");
    }
	
}