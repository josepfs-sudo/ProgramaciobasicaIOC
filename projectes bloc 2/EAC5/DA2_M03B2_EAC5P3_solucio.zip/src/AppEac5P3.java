import java.util.Scanner;

public class AppEac5P3 {
	static final int maxMagatzem=25000;
    String mVarietat[] = 
                {"Ull de llebre","Garnatxa","Xarel·lo","Macabeu","Parellada"};
    int mQuantitat[]={4987,5764,4,12763,9474};
    int quantitatTotalRaim = 0;
    
    
    public static void main(String[] args) {
    	AppEac5P3 prg = new AppEac5P3();
        prg.inici();
    }
    
    private void inici(){
        int opcMenuPpal;
        DadesProduccio dadesProd= new DadesProduccio();
        do{
            UtilsES.mostrarTitol("Menú principal");
            System.out.println("1. Entrada Raim");
            System.out.println("2. Sortida Raim");
            System.out.println("3. Estat Magatzem");
            System.out.println("4. Estimació Producció");
            System.out.println("5. Produïr i embotellar");
            System.out.println("6. Mostrar Producció");
            System.out.println("0. Sortir");

            opcMenuPpal = UtilsES.demanarEnter("Esculliu una opció: ", "Aquest menú només accepta valors numèrics");
            switch(opcMenuPpal){
            case 0: 
                    break;
            case 1: 
                menuEntrada();
                break;
            case 2: 
                menuSortida();
                break;
            case 3: 
                estatMagatzem(dadesProd);
                break;
            case 4:
            	estimacioProduccio(dadesProd);
                break;
            case 5:
                produirEmbotellar(dadesProd);
                break;
            case 6: 
                GestioProduccio.mostraProduccio(dadesProd.aProducte,dadesProd.aProduccio);
                break;
            default:
                System.out.println("Heu de triar un nombre entre 0 i 6");
            }
        }while(opcMenuPpal!=0);
     }
     
     /*Procediment que demana el nom de la varietat i els quilograms.
      A continuació crida a la funció entradaRaim si rep true, la operació ha anat bé
     altrament es que hi ha hagut algun problema (nom raim o quantitat). */ 
     private void menuEntrada() {
        String vVarietat;
        int vQuantitat=-1;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introdueix el nom de la varietat?");
        vVarietat = scanner.nextLine();
        System.out.println("Introdueix el nobre de quilograms (0-1000)?");
        do {
                vQuantitat = scanner.nextInt();
                if(vQuantitat<0) {
                    System.out.println("La quantitat no pot ser negativa. Torneu-ho a intentar.");   			 
                }else if(vQuantitat>1000) {
                    System.out.println("La quantitat no pot ser superior a 1000. Torneu-ho a intentar.");   			 
                }
        }while (vQuantitat<0 || vQuantitat>1000);

        entradaRaim(vVarietat, vQuantitat);
     } 
     
     /*Procediment que demana el nom de la varietat i els quilograms.
     A continuació crida a la funció sortidaRaim si rep true, la operació ha anat bé
     altrament es que hi ha hagut algun problema (nom raim o quantitat). */ 
     private void menuSortida() {
        String vVarietat;
        int vQuantitat=-1;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Introdueix el nom de la varietat?");
        vVarietat = scanner.nextLine();
        System.out.println("Introdueix el nombre de quilograms (0-1000)?");
        do {
                vQuantitat = scanner.nextInt();
                if(vQuantitat<0) {
                    System.out.println("La quantitat no pot ser negativa. Torneu-ho a intentar.");   			 
                }else if(vQuantitat>1000) {
                    System.out.println("La quantitat no pot ser superior a 1000. Torneu-ho a intentar.");   			 
                }
        }while (vQuantitat<0 || vQuantitat>1000);

        sortidaRaim(vVarietat, vQuantitat);
     }
     
     private void estatMagatzem(DadesProduccio dadesProd) {
      	for (int i = 0; i<mVarietat.length;i++) {
      		System.out.println("Varietat: " + mVarietat[i] + " Quantitat: " + mQuantitat[i] );
      	}
      	System.out.println("Quantitat de Raim total al magatzem: "+ quantitatTotalRaim);
      	
     }
 
     //Mètode que registra l'entrada de qRaim Quilograms de Raim.    
     private void entradaRaim(String varietat, int qRaim){
        if ((qRaim + quantitatTotalRaim)<=maxMagatzem) {
            int posVarietat=posicioVarietat(varietat);
            if (posVarietat>-1) {
                mQuantitat[posVarietat] = mQuantitat[posVarietat] + qRaim;
                quantitatTotalRaim=quantitatTotalRaim+qRaim;
                System.out.println("Entrada de Raim realitzada correctament.");
            }else {
                System.out.println("Varietat no trobada");
                System.out.println("Entrada no realitzada.");
            }        		   
        }else {
            System.out.println("La quantitat supera la capacitat màxima del magatzem.");
            System.out.println("Entrada no realitzada.");
        }
    }

    //Mètode que registra la sortida de qRaim Quilograms de Raim.  
    private void sortidaRaim(String varietat, int qRaim){
        if ((quantitatTotalRaim-qRaim)>=0) {
            int posVarietat=posicioVarietat(varietat);
            if (posVarietat>-1) {
                if ((mQuantitat[posVarietat] - qRaim)>0) {
                    mQuantitat[posVarietat] = mQuantitat[posVarietat] - qRaim;
                    quantitatTotalRaim=quantitatTotalRaim-qRaim;
                    System.out.println("Sortida de Raim realitzada correctament.");   			 
                }
                else {
                    System.out.println("Quantitat no disponible per aquesta varitetat: "+ mQuantitat[posVarietat]);
                    System.out.println("Sortida no realitzada.");
                }
            }else {
                System.out.println("Varietat no trobada");
                System.out.println("Sortida no realitzada.");
            }
        }else {
            System.out.println("La quantitat és superior al raïm disponible al magatzem: " + quantitatTotalRaim);
            System.out.println("Sortida no realitzada.");
        }
    }
     
     
    //Mètode que cerca dins l'array de varietats la varietat rebuda per paràmetre.
    private int posicioVarietat(String varietat){
    	int pTrobada=-1;
        for (int i=0; i<mVarietat.length;i++) {
            if (varietat.equals(mVarietat[i])){
                pTrobada= i;
            }
        }
        return pTrobada;
    } 
    
    private void estimacioProduccio(DadesProduccio dadesProd) {
    	String nomProducte;
    	int numAmpolles;
        UtilsES.mostrarTitol("Procediment per estimar la producció");        
    	nomProducte=UtilsES.demanarString("Per quin producte vols saber la estimació de produccio?", "Heu d'entrar el nom d'un producte");
    	numAmpolles=GestioProduccio.calculaAmpolles(nomProducte, dadesProd.aProducte, dadesProd.mCupatge, mQuantitat);
        UtilsES.mostrarResultat("La estimació actual de producció per " + nomProducte + " és de: " + numAmpolles + " ampolles"); 
    }
    
    private void produirEmbotellar(DadesProduccio dadesProd) {
    	String nomProducte;
    	int numAmpolles=0;
    	int maxAmpolles=0;
    	int [] calQuilAmp;
    	System.out.println();
    	nomProducte=UtilsES.demanarString("Quin producte vols produïr?", "Heu d'entrar el nom d'un producte");
    	maxAmpolles=GestioProduccio.calculaAmpolles(nomProducte, dadesProd.aProducte, dadesProd.mCupatge, mQuantitat);
    	if (maxAmpolles>0) {
            do{
                numAmpolles=UtilsES.demanarEnter("Quantes ampolles vols produïr", "Has d'escriure un valor enter.");
                if (numAmpolles>maxAmpolles){
                        UtilsES.mostrarAlesta("El nombre d'ampolles és massa elevat. El nombre no pot superar les " + maxAmpolles);
                }
            }while (numAmpolles>maxAmpolles);  		
            calQuilAmp=GestioProduccio.calculaQuilogramsAmpolles(numAmpolles, nomProducte, dadesProd.aProducte, dadesProd.mCupatge);
            dadesProd.aProduccio[GestioProduccio.posicioProducte(nomProducte, dadesProd.aProducte)]+=numAmpolles;
            for (int i=0;i<calQuilAmp.length;i++) {
                mQuantitat[i]=mQuantitat[i]-calQuilAmp[i];
            }
            UtilsES.mostrarResultat("La producció s'ha actualitzat amb èxit");
    	}
    	else {
    		System.out.println("No és possible produir aquest producte");
    	}
    }
    
}