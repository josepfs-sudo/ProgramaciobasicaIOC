public class DadesProduccio {
	String [] aProducte= {"Cava Castells","Blanc Castells","Negre Castells"};
	int [][] mCupatge={{0,0,30,50,20},{0,0,100,0,0},{60,40,0,0,0}};
	int [] aProduccio={0,0,0};
}