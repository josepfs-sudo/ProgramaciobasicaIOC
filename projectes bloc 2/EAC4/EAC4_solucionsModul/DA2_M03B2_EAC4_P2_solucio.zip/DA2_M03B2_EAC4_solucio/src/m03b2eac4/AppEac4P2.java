package m03b2eac4;

import java.util.Scanner;

public class AppEac4P2 {
	static final int maxMagatzem=25000;
    String mVarietat[] = 
                {"Ull de llebre","Garnatxa","Xarel·lo","Macabeu","Parellada"};
    int mQuantitat[]={0,0,0,0,0};
    int quantitatTotalRaim = 0;
    
    
    public static void main(String[] args) {
        AppEac4P2 prg = new AppEac4P2();
        prg.inici();
    }
    
    private void inici(){
        int opcMenuPpal;
        do{
            Scanner scanner = new Scanner(System.in);
            System.out.println("Quina operació vols fer?");
            System.out.println("1. Entrada Raim");
            System.out.println("2. Sortida Raim");
            System.out.println("3. Estat Magatzem");
            System.out.println("0. Sortir");

            opcMenuPpal = scanner.nextInt();
            switch(opcMenuPpal){
            case 0: 
                    break;
            case 1: 
                    menuEntrada();
                    break;
            case 2: 
                    menuSortida();
                    break;
            case 3: 
                    estatMagatzem();
                    break;
            default:
                    System.out.println("Heu de triar un nombre entre 0 i 3");
            }
        }while(opcMenuPpal!=0);
     }
     
     /*Procediment que demana el nom de la varietat i els quilograms.
      A continuació crida a la funció entradaRaim si rep true, la operació ha anat bé
     altrament es que hi ha hagut algun problema (nom raim o quantitat). */ 
     private void menuEntrada() {
        String vVarietat;
        int vQuantitat=-1;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introdueix el nom de la varietat?");
        vVarietat = scanner.nextLine();
        System.out.println("Introdueix el nobre de quilograms (0-1000)?");
        do {
                vQuantitat = scanner.nextInt();
                if(vQuantitat<0) {
                    System.out.println("La quantitat no pot ser negativa. Torneu-ho a intentar.");   			 
                }else if(vQuantitat>1000) {
                    System.out.println("La quantitat no pot ser superior a 1000. Torneu-ho a intentar.");   			 
                }
        }while (vQuantitat<0 || vQuantitat>1000);

        entradaRaim(vVarietat, vQuantitat);
     } 
     
     /*Procediment que demana el nom de la varietat i els quilograms.
     A continuació crida a la funció sortidaRaim si rep true, la operació ha anat bé
     altrament es que hi ha hagut algun problema (nom raim o quantitat). */ 
     private void menuSortida() {
        String vVarietat;
        int vQuantitat=-1;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Introdueix el nom de la varietat?");
        vVarietat = scanner.nextLine();
        System.out.println("Introdueix el nombre de quilograms (0-1000)?");
        do {
                vQuantitat = scanner.nextInt();
                if(vQuantitat<0) {
                    System.out.println("La quantitat no pot ser negativa. Torneu-ho a intentar.");   			 
                }else if(vQuantitat>1000) {
                    System.out.println("La quantitat no pot ser superior a 1000. Torneu-ho a intentar.");   			 
                }
        }while (vQuantitat<0 || vQuantitat>1000);

        sortidaRaim(vVarietat, vQuantitat);
     }
     
     private void estatMagatzem() {
      	for (int i = 0; i<mVarietat.length;i++) {
      		System.out.println("Varietat: " + mVarietat[i] + " Quantitat: " + mQuantitat[i] );
      	}
      	System.out.println("Quantitat de Raim total al magatzem: "+ quantitatTotalRaim);
     }
 
     //Mètode que registra l'entrada de qRaim Quilograms de Raim.    
     private void entradaRaim(String varietat, int qRaim){
        if ((qRaim + quantitatTotalRaim)<=maxMagatzem) {
            int posVarietat=posicioVarietat(varietat);
            if (posVarietat>-1) {
                mQuantitat[posVarietat] = mQuantitat[posVarietat] + qRaim;
                quantitatTotalRaim=quantitatTotalRaim+qRaim;
                System.out.println("Entrada de Raim realitzada correctament.");
            }else {
                System.out.println("Varietat no trobada");
                System.out.println("Entrada no realitzada.");
            }        		   
        }else {
            System.out.println("La quantitat supera la capacitat màxima del magatzem.");
            System.out.println("Entrada no realitzada.");
        }
    }

    //Mètode que registra la sortida de qRaim Quilograms de Raim.  
    private void sortidaRaim(String varietat, int qRaim){
        if ((quantitatTotalRaim-qRaim)>=0) {
            int posVarietat=posicioVarietat(varietat);
            if (posVarietat>-1) {
                if ((mQuantitat[posVarietat] - qRaim)>0) {
                    mQuantitat[posVarietat] = mQuantitat[posVarietat] - qRaim;
                    quantitatTotalRaim=quantitatTotalRaim-qRaim;
                    System.out.println("Sortida de Raim realitzada correctament.");   			 
                }
                else {
                    System.out.println("Quantitat no disponible per aquesta varitetat: "+ mQuantitat[posVarietat]);
                    System.out.println("Sortida no realitzada.");
                }
            }else {
                System.out.println("Varietat no trobada");
                System.out.println("Sortida no realitzada.");
            }
        }else {
            System.out.println("La quantitat és superior al raïm disponible al magatzem: " + quantitatTotalRaim);
            System.out.println("Sortida no realitzada.");
        }
    }
     
     
    //Mètode que cerca dins l'array de varietats la varietat rebuda per paràmetre.
    private int posicioVarietat(String varietat){
    	int pTrobada=-1;
        for (int i=0; i<mVarietat.length;i++) {
            if (varietat.equals(mVarietat[i])){
                pTrobada= i;
            }
        }
        return pTrobada;
    }  
}